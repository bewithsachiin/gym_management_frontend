import React from 'react'

const Campaigns = () => {
  return (
    <div>Campaigns</div>
  )
}

export default Campaigns