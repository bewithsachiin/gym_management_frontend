import React from 'react'

const Marketing = () => {
  return (
    <div>Marketing</div>
  )
}

export default Marketing