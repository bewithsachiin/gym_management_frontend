import React from 'react';

const ReceptionistHandleMembership = () => {
  return (
    <div>
      ReceptionistHandleMembership
    </div>
  );
}

export default ReceptionistHandleMembership;
