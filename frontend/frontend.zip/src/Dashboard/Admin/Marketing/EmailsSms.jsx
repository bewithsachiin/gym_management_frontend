import React from 'react'

const EmailsSms = () => {
  return (
    <div>EmailsSms</div>
  )
}

export default EmailsSms